# Your Favicon Package

This package was generated with [RealFaviconGenerator](https://realfavicongenerator.net/) [v0.16](https://realfavicongenerator.net/change_log#v0.16)

## Install instructions

To install this package:

Extract this package in <code>&lt;web site&gt;<?php echo /ttt/ ?></code>. If your site is <code>http://www.example.com</code>, you should be able to access a file named <code>http://www.example.com<?php echo /ttt/ ?>favicon.ico</code>.

Insert the following code in the `head` section of your pages:

    <link rel="apple-touch-icon" sizes="57x57" href="/ttt/apple-touch-icon-57x57.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="60x60" href="/ttt/apple-touch-icon-60x60.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="72x72" href="/ttt/apple-touch-icon-72x72.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="76x76" href="/ttt/apple-touch-icon-76x76.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="114x114" href="/ttt/apple-touch-icon-114x114.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="120x120" href="/ttt/apple-touch-icon-120x120.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="144x144" href="/ttt/apple-touch-icon-144x144.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="152x152" href="/ttt/apple-touch-icon-152x152.png?v=lkdGjbJg58">
    <link rel="apple-touch-icon" sizes="180x180" href="/ttt/apple-touch-icon-180x180.png?v=lkdGjbJg58">
    <link rel="icon" type="image/png" sizes="32x32" href="/ttt/favicon-32x32.png?v=lkdGjbJg58">
    <link rel="icon" type="image/png" sizes="16x16" href="/ttt/favicon-16x16.png?v=lkdGjbJg58">
    <link rel="manifest" href="/ttt/site.webmanifest?v=lkdGjbJg58">
    <link rel="mask-icon" href="/ttt/safari-pinned-tab.svg?v=lkdGjbJg58" color="#073642">
    <link rel="shortcut icon" href="/ttt/favicon.ico?v=lkdGjbJg58">
    <meta name="apple-mobile-web-app-title" content="Tappy-Tap-Tap">
    <meta name="application-name" content="Tappy-Tap-Tap">
    <meta name="msapplication-TileColor" content="#073642">
    <meta name="msapplication-TileImage" content="/ttt/mstile-144x144.png?v=lkdGjbJg58">
    <meta name="msapplication-config" content="/ttt/browserconfig.xml?v=lkdGjbJg58">
    <meta name="theme-color" content="#073642">

*Optional* - Check your favicon with the [favicon checker](https://realfavicongenerator.net/favicon_checker)